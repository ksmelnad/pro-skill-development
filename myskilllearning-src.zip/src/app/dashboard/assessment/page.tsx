import Assessment from "@/components/userDashboard/assessment";

export default async function page() {
  return (
    <div>
      <h2 className="section-title">Assessment</h2>
      <Assessment />
    </div>
  );
}
