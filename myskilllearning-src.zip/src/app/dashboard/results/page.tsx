import Results from "@/components/userDashboard/results";

export default async function page() {
  return (
    <div className="">
      <h3 className="section-title">Results </h3>
      <Results />
    </div>
  );
}
