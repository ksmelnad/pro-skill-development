import Certificate from "@/components/userDashboard/certificate";

export default async function page() {
  return <Certificate />;
}
