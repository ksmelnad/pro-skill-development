import Companies from "@/components/companies";
import CompaniesMarquee from "@/components/companiesMarquee";
import CTA from "@/components/cta";
import Features from "@/components/features";
import Footer from "@/components/footer";
import Hero from "@/components/hero";
import Navbar from "@/components/navbar";
import Newsletter from "@/components/newsletter";

export default async function Home() {
  return (
    <main>
      {/* <Navbar /> */}
      <Hero />
      <Features />
      <CompaniesMarquee />
      <Companies />
      <CTA />
      <Newsletter />
      <Footer />
    </main>
  );
}
