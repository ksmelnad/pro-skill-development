export default async function Certificate() {
  return <div>certificate</div>;
}
